package com.inventario.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
